#ifndef __CRC_H_
#define __CRC_H_
















extern INT16U CRC16 (INT8U * puchMsg, INT16U usDataLen ); 
#endif
